<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Survey extends Model
{
    // Table Name
    protected $table = 'Survey';
    // Primary Key
    public $primaryKey = 'surveyId';
 

    public function user(){
        return $this->belongsTo('App\User');
    }
}
