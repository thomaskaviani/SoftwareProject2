<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    
    use Notifiable;
    protected $primaryKey = 'empId';
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    protected $table = 'EmployeeDB';

    public function posts() {
         return $this->hasMany('App\Post', 'empId');
    }

    public function certificates() {
        return $this->hasMany('App\Certificate', 'empId');
   }

    public function trainings() {
        return $this->hasMany('App\TrainingRequest', 'empId');
   }
}
