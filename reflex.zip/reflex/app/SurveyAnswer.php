<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SurveyAnswer extends Model
{
    // Table Name
    protected $table = 'Survey_a';
    // Primary Key
    public $primaryKey = 'answerId';

    public $timestamps = false;

    public function user(){
        return $this->belongsTo('App\User');
    }
}
