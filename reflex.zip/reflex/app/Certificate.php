<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Certificate extends Model
{
    // Table Name
    protected $table = 'CertificateWeb';
    // Primary Key
    public $primaryKey = 'certificateId';
 
    public function user(){
        return $this->belongsTo('App\User');
    }
}
