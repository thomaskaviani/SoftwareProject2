<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Storage;
use App\Survey;
use App\SurveyQuestion;
use App\SurveyAnswer;
use App\User;
use DB;

class SurveysController extends Controller
{
   
    public function index()
    {
        $userId = auth()->user()->empId;

        $trainingrequests = DB::table('Survey')
        ->join('TrainingRequest', 'TrainingRequest.trainingId', '=', 'Survey.trainingId')
        ->where([
                ['TrainingRequest.empId', '=', $userId],
                ['TrainingRequest.approval', '=', 2],
            ])
        ->get();

        return view('surveys.index', compact('trainingrequests'));
    }

    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        $this->validate($request, [
            'questionId' => 'required',
            'answer' => 'required',
        ]);

        //DB::table('Survey_a')->insert(
        //[   'empId' => auth()->user()->empId,
        //    'surveyId' => $request->input('surveyId'), 
         //   'questionId' => $request->input('questionId'), 
         //   'answer' => $request->input('answer')
        //]);
        
        $answer = new SurveyAnswer;
        $answer->empId= auth()->user()->empId;
        $answer->surveyId = $request->input('surveyId');
        $answer->questionId = $request->input('questionId');
        $answer->answer = $request->input('answer');
        $answer->save();

        return redirect('/surveys')->with('success', 'Thank you for your answer!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        
        $surveys =  SurveyQuestion::find($id);  
        return view('surveys.show')->with('surveys',$surveys);   
        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
