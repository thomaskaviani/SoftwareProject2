<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Session extends Model
{
    // Table Name
    protected $table = 'Sessions';
    // Primary Key
    public $primaryKey = 'sessionId';
    

    public function user(){
        return $this->belongsTo('App\User');
    }
}
