<?php $__env->startSection('content'); ?>
<a href="/surveys" class="btn btn-default">Go back</a>

<?php
$surveyId = $surveys->surveyId;
				$questions = DB::table('Survey_q')
					->leftJoin('Survey_a', 'Survey_a.questionId', '=','Survey_q.questionId')
					->leftJoin('Survey', 'Survey_a.surveyId', '=','Survey.surveyId')
					->select('Survey_q.*')
					->where(
						[
						['Survey_q.surveyId', '=', $surveyId],
	            		['Survey_a.empId', '=', null],
	            	])
					->get();
?>
  <?php if(count($questions) > 0): ?>
  <div class="row">
	            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					
						<div class="col-md-4 col-sm-8">
							<h3>
								<?php echo e($question->question); ?>

							</h3>
							
								<?php echo Form::open(['action' => 'SurveysController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

									<?php if($question->typeId == '1'): ?>
									<div class="form-group">
										<?php echo e(Form::textArea('answer', '', ['class' => 'form-control','rows' => 2, 'cols' => 40,'placeholder' => 'Write your answer'])); ?>

									</div>
									<?php else: ?>
									<div class="form-group">
										<?php echo e(Form::radio('answer', '1')); ?> 1
										<?php echo e(Form::radio('answer', '2')); ?> 2
										<?php echo e(Form::radio('answer', '3')); ?> 3
										<?php echo e(Form::radio('answer', '4')); ?> 4
										<?php echo e(Form::radio('answer', '5')); ?> 5
									</div>
									<?php endif; ?>
                					<div class="form-group">
										<?php echo e(Form::hidden('surveyId', $surveys->surveyId)); ?>

                    					<?php echo e(Form::hidden('questionId', $question->questionId)); ?>

               	 					</div>
               	 					<?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary'])); ?>		
                				<?php echo Form::close(); ?>

							
						</div>
					
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
				<?php else: ?>
					<h3>You have finished this survey</h3>
				<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>