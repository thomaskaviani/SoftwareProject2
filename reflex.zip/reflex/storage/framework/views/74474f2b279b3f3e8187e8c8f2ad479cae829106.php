<?php $__env->startSection('content'); ?>
    <div class="jumbotron text-center">
        <h1>REFLEX</h1>
        <p>Log in to apply for REFLEX trainings </p>
        <p><a class="btn btn-primary btn-lg" href="/login" role="button">Login</a> </p>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>