<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">


                <div class="panel-body">
                    
                    <h3>Manage training requests</h3>
                    <?php if(count($trainingrequests)>0): ?>
                    <table class="table table-striped">
                            <td>Employee</td>
                            <td>Training Name</td>
                        <td></td>
                        <td></td>
                        <?php $__currentLoopData = $trainingrequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainingrequest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                    $empId = $trainingrequest->empId;
				$empname = DB::table('EmployeeDB')
					->where('empId', '=', $empId)
					->value('name');

        
?>
                        <tr> 
                                <td><?php echo e($empname); ?></td>
                            <td><?php echo e($trainingrequest->name); ?></td>
                            
                         <td>  <?php echo Form::open(['action' => ['ManagerController@update', $trainingrequest->requestId], 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                            <?php echo Form::hidden('requestId', $trainingrequest->requestId, ['class' => 'form-control', 'readonly']); ?> 
                            <?php echo Form::hidden('approval', 2, ['class' => 'form-control', 'readonly']); ?> <?php echo e(Form::hidden('_method','PUT')); ?> 
                            <?php echo e(Form::submit('Accept', ['class' => 'btn btn-primary '])); ?>

                        <?php echo Form::close(); ?>

                           </td>
                           <td>
                           <?php echo Form::open(['action' => ['ManagerController@update', $trainingrequest->requestId], 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                            <?php echo Form::hidden('requestId', $trainingrequest->requestId, ['class' => 'form-control', 'readonly']); ?> 
                            <?php echo Form::hidden('approval', 0, ['class' => 'form-control', 'readonly']); ?> <?php echo e(Form::hidden('_method','PUT')); ?> 
                            <?php echo e(Form::submit('Decline', ['class' => 'btn btn-primary '])); ?>

                        <?php echo Form::close(); ?>

                        </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    <?php else: ?>
                        <p>You have no requested trainings to manage</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>