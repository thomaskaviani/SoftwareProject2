<?php $__env->startSection('content'); ?>
    <h1>All sessions</h1>
    <?php if(count($sessions) > 0): ?>
        <?php $__currentLoopData = $sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="well">
                <div class="row">
                    
                    <div class="col-md-8 col-sm-8">
                        <h3><a href="/surveys/<?php echo e($session->sessionId); ?>"><?php echo e($session->sessionName); ?></a></h3>
                        <h1><?php echo e($session->startTime); ?></h1>
                        <h1><?php echo e($session->endTime); ?></h1>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($sessions->links()); ?>

    <?php else: ?>
        <p>No sessions found </p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>