<?php $__env->startSection('content'); ?>
    
    

<?php if(count($trainingrequests) > 0): ?>
 <?php $__currentLoopData = $trainingrequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainingrequest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 
 

<div class="col-lg-6">
<div class="well col-lg-12">
	<div class="row">
		<div class="col-lg-12">
			<h3>
				
			</h3>
            <?php
				$trainingId = $trainingrequest->trainingId;
				$surveyName = DB::table('Survey')
					->where('trainingId', $trainingId)
					->value('surveyName');
                
				?>
                <h3><a href="/surveys/<?php echo e($trainingrequest->surveyId); ?>"><?php echo e($surveyName); ?></a></h3>
		</div>
	</div>
	</div>
</div>
</a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
<h4>No surveys found</h4>
<?php endif; ?> <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>