<?php $__env->startSection('content'); ?>
<?php
        $userId = auth()->user()->empId;
        $manager = DB::table('EmployeeDB')->where('empId', $userId)->value('manager');
        
?>
    <h1>All trainings</h1>
    <?php if(count($trainings) > 0): ?>
   
        <?php $__currentLoopData = $trainings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $training): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   
            
        <div class="well col-md-4" style="min-height:200px">
                    <div class="col-md-12 col-sm-4 text-center">
                        <h3><a href="/trainings/<?php echo e($training->trainingId); ?>"><?php echo e($training->name); ?></a></h3>
                        <div class="text-center">
                        <?php echo Form::open(['action' => ['TrainingRequestsController@store'], 'method' => 'POST']); ?>

                                    <?php echo e(Form::hidden('trainingId', $training->trainingId)); ?>

                                    <?php echo e(Form::hidden('name', $training->name)); ?>

                                    <?php echo e(Form::hidden('goal', $training->goal)); ?>

                                    <?php echo e(Form::hidden('forManager', $manager)); ?>

                                    <?php echo e(Form::hidden('_method', 'POST')); ?>

                                    <?php echo e(Form::submit('Request',['class' => 'btn btn-danger'])); ?>

                        <?php echo Form::close(); ?>

                        </div>
                    </div>
            
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
    <?php else: ?>
        <p>No trainings found </p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>