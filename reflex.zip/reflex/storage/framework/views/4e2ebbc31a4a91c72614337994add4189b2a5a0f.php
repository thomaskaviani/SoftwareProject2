<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Home</div>

                <div class="panel-body">
                    
                    <h3>Your Trainings Request</h3>
                    <?php if(count($TrainingRequest)>0): ?>
                    <table class="table table-striped">
                       
                        <?php $__currentLoopData = $TrainingRequest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $training): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($training->name); ?></td>
                            
                            <td> <?php echo Form::open(['action' => ['TrainingRequestsController@destroy', $training->trainingId], 'method' => 'TRAININGREQUEST','class'=>'pull-right']); ?>

                                    <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                                     <?php echo e(Form::submit('Delete',['class' => 'btn btn-danger'])); ?>

                                <?php echo Form::close(); ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    <?php else: ?>
                        <p>You have no requested trainings</p>
                    <?php endif; ?>
                     <a href="/trainingrequests/create" class="btn btn-primary">Request Training</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>