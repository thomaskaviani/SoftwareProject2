<?php $__env->startSection('content'); ?>
<?php
$trainingId = $training->trainingId;
				$sessions = DB::table('Sessions')
					->select('Sessions.*')
					->where('Sessions.trainingId', '=', $trainingId)
                    ->orderBy('Sessions.startTime')
					->get();

        $userId = auth()->user()->empId;
        $manager = DB::table('EmployeeDB')->where('empId', $userId)->value('manager');
        
?>
<a href="/trainings" class="btn btn-default">Go back</a>
<?php if(count($sessions) > 0): ?>
<h1 class="text-center"><u><?php echo e($training->name); ?></u></h1>
				<?php $__currentLoopData = $sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php
				$teacherId = $session->teacherId;
				$teacher = DB::table('Teacher')
					->where('Teacher.teacherId', '=', $teacherId)
					->value('teacherName');

					$addressId = $session->addressId;
				$street = DB::table('Address')
					->where('Address.addressId', '=', $addressId)
					->value('street');
					$number = DB::table('Address')
					->where('Address.addressId', '=', $addressId)
					->value('number');
					$bus = DB::table('Address')
					->where('Address.addressId', '=', $addressId)
					->value('bus');
					$postalcode = DB::table('Address')
					->where('Address.addressId', '=', $addressId)
					->value('postalcode');
					$place = DB::table('Address')
					->where('Address.addressId', '=', $addressId)
					->value('place');
					$country = DB::table('Address')
					->where('Address.addressId', '=', $addressId)
					->value('country');
?>

						<div class="col-md-6 col-sm-6 text-center">
							<h3>
                            
								<b><?php echo e($session->sessionName); ?></b>
							</h3>
                            <h4>
								Start time: <?php echo e($session->startTime); ?>

							</h4>
                             <h4>
								End time: <?php echo e($session->endTime); ?>

							</h4>
						<h4>
							Teacher: <?php echo e($teacher); ?>

						</h4>
						<h4><b>Location</b></h4>
						<h4>
								<?php echo e($street); ?> <?php echo e($number); ?>, <?php echo e($place); ?> <?php echo e($postalcode); ?>

							</h4>
						</div>
					
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php else: ?>
					<h3>There are no sessions</h3>
				<?php endif; ?>
				<div class="col-md-12 text-center">
<?php echo Form::open(['action' => ['TrainingRequestsController@store'], 'method' => 'POST','class'=>'text-center']); ?>

                                    <?php echo e(Form::hidden('trainingId', $training->trainingId)); ?>

                                    <?php echo e(Form::hidden('name', $training->name)); ?>

                                    <?php echo e(Form::hidden('goal', $training->goal)); ?>

                                    <?php echo e(Form::hidden('forManager', $manager)); ?>

                                    <?php echo e(Form::hidden('_method', 'POST')); ?>

                                    <?php echo e(Form::submit('Request',['class' => 'btn btn-danger text-center'])); ?>

                        <?php echo Form::close(); ?>

    
				</div>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>