<?php $__env->startSection('content'); ?>
    <h1></h1>
    <?php if(count($certificates) > 0): ?>
        
            <div class="well">
                    <div class="row">
                    <?php $__currentLoopData = $certificates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certificate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                    <div class="col-md-4 col-sm-4 text-center">
                        <img style = "max-height:150px" src="/storage/files/<?php echo e($certificate->file); ?>">
                        <h3><a href="/certificates/<?php echo e($certificate->certificateId); ?>"><?php echo e($certificate->description); ?></a></h3>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            </div>
        
    <?php else: ?>
        <h4>No certificates found </h4>
    <?php endif; ?>
<div class="text-center">
    <a href="/certificates/create" class="btn btn-primary text-center">Upload Certificate</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>