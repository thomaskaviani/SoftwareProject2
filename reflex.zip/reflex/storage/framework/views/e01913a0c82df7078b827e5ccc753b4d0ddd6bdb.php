<?php $__env->startSection('content'); ?>
    <h1>Request training </h1>
    <?php echo Form::open(['action' => 'TrainingRequestsController@store', 'method' => 'TRAININGREQUEST', 'enctype' => 'multipart/form-data']); ?>

        <div class="form-group">
            <?php echo e(Form::label('name','Training Name ')); ?>

            <?php echo e(Form::text('name', '', ['class' => 'form-control'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('goal','Goal description')); ?>

            <?php echo e(Form::textarea('goal', '', [ 'class' => 'form-control'])); ?>

        </div>
        
        <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

    <?php echo Form::close(); ?>

    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>