<?php $__env->startSection('content'); ?>
<a href="/certificates" class="btn btn-default">Go back</a>
    <h1><?php echo e($certificate->title); ?></h1>
     <img style = "width:100%" src="/storage/files/<?php echo e($certificate->file); ?>">
     <br><br>
    <div>
        <?php echo $certificate->description; ?>

    </div>
    <hr>

    <hr>
    <?php if(Auth::user()->empId == $certificate->empId): ?>

                <?php echo Form::open(['action' => ['CertificatesController@destroy', $certificate->certificateId], 'method' => 'certificate','class'=>'pull-right']); ?>

                    <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                    <?php echo e(Form::submit('Delete',['class' => 'btn btn-danger'])); ?>

                <?php echo Form::close(); ?>

        <?php endif; ?>
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>