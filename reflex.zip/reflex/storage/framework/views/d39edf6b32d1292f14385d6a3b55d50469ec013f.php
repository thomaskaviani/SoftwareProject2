<?php $__env->startSection('content'); ?>
<a href="/trainings" class="btn btn-default">Go back</a>
    <h1><?php echo e($training->name); ?></h1>
     
     <br><br>
    <div>
        <?php echo $training->goal; ?>

    </div>
   <?php echo Form::open(['action' => ['TrainingRequestsController@store', $training->trainingId], 'method' => 'POST','class'=>'pull-right']); ?>

                                    <?php echo e(Form::hidden('name', $training->name)); ?>

                                    <?php echo e(Form::hidden('goal', $training->goal)); ?>

                                    <?php echo e(Form::hidden('_method', 'POST')); ?>

                                    <?php echo e(Form::submit('Request',['class' => 'btn btn-danger'])); ?>

                        <?php echo Form::close(); ?>

                        

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>