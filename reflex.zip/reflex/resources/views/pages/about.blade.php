@extends('layouts.app')

@section('content')
        <h1> <?php echo $title; ?></h1>
        <p>This web application is made so you can request trainings. </p>
    </body>
@endsection
