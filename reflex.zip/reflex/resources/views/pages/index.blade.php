@extends('layouts.app')

@section('content')
    <div class="jumbotron text-center">
        <h1>REFLEX</h1>
        <p>Log in to apply for REFLEX trainings </p>
        <p><a class="btn btn-primary btn-lg" href="/login" role="button">Login</a> </p>
        </div>
@endsection