@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-body">
                    
                    <h3>Your Trainings Request</h3>
                    @if (count($TrainingRequest)>0)
                    <table class="table table-striped">
                            <td><b>Training Name</b></td>
                            <td><b>Approval Status</b></td>
                            <td></td>
                        @foreach($TrainingRequest as $training)
                        <tr>
                            <td>{{$training->name}}</td>
                            @if($training->approval=='0')
                            <td>Declined</td>
                            @elseif($training->approval=='2')
                            <td>Accepted</td>
                            @elseif($training->approval=='1')
                            <td>Awaiting</td>
                            @endif
                            <td> {!!Form::open(['action' => ['TrainingRequestsController@destroy', $training->trainingId], 'method' => 'TRAININGREQUEST','class'=>'pull-right'])!!}
                                    {{Form::hidden('_method', 'DELETE')}}
                                     {{Form::submit('Delete',['class' => 'btn btn-danger'])}}
                                {!!Form::close()!!}
                            </td>
                        </tr>
                        @endforeach
                    </table>
                    @else
                        <p>You have no requested trainings</p>
                    @endif
                     <a href="/trainingrequests/create" class="btn btn-primary">Request Training</a>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
