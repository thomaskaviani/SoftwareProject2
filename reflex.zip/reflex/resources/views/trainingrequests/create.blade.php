@extends('layouts.app')

@section('content')
<?php
        $userId = auth()->user()->empId;
        $manager = DB::table('EmployeeDB')->where('empId', $userId)->value('manager');
        
?>
    <h1>Request training </h1>
    {!! Form::open(['action' => 'TrainingRequestsController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']) !!}
        <div class="form-group">
            
            {{Form::hidden('trainingId', -1, [ 'class' => 'form-control'])}}
            {{Form::label('name','Training Name ')}}
            {{Form::text('name', '', ['class' => 'form-control'])}}
        </div>
        <div class="form-group">
            {{Form::label('goal','Goal description')}}
            {{Form::textarea('goal', '', [ 'class' => 'form-control'])}}
            {{Form::hidden('forManager', $manager)}}
        </div>
        
        {{Form::submit('Submit', ['class'=>'btn btn-primary'])}}
    {!! Form::close() !!}
    
    
@endsection