@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">


                <div class="panel-body">
                    
                    <h3>Manage training requests</h3>
                    @if (count($trainingrequests)>0)
                    <table class="table table-striped">
                            <td>Employee</td>
                            <td>Training Name</td>
                        <td></td>
                        <td></td>
                        @foreach($trainingrequests as $trainingrequest)
                        <?php
                    $empId = $trainingrequest->empId;
				$empname = DB::table('EmployeeDB')
					->where('empId', '=', $empId)
					->value('name');

        
?>
                        <tr> 
                                <td>{{$empname}}</td>
                            <td>{{$trainingrequest->name}}</td>
                            
                         <td>  {!! Form::open(['action' => ['ManagerController@update', $trainingrequest->requestId], 'method' => 'POST', 'enctype' => 'multipart/form-data']) !!}
                            {!! Form::hidden('requestId', $trainingrequest->requestId, ['class' => 'form-control', 'readonly']) !!} 
                            {!! Form::hidden('approval', 2, ['class' => 'form-control', 'readonly']) !!} {{Form::hidden('_method','PUT')}} 
                            {{Form::submit('Accept', ['class' => 'btn btn-primary '])}}
                        {!! Form::close() !!}
                           </td>
                           <td>
                           {!! Form::open(['action' => ['ManagerController@update', $trainingrequest->requestId], 'method' => 'POST', 'enctype' => 'multipart/form-data']) !!}
                            {!! Form::hidden('requestId', $trainingrequest->requestId, ['class' => 'form-control', 'readonly']) !!} 
                            {!! Form::hidden('approval', 0, ['class' => 'form-control', 'readonly']) !!} {{Form::hidden('_method','PUT')}} 
                            {{Form::submit('Decline', ['class' => 'btn btn-primary '])}}
                        {!! Form::close() !!}
                        </td>
                        </tr>
                        @endforeach
                    </table>
                    @else
                        <p>You have no requested trainings to manage</p>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
