@extends('layouts.app')

@section('content')
<a href="/surveys" class="btn btn-default">Go back</a>

<?php
$surveyId = $surveys->surveyId;
				$questions = DB::table('Survey_q')
					->leftJoin('Survey_a', 'Survey_a.questionId', '=','Survey_q.questionId')
					->leftJoin('Survey', 'Survey_a.surveyId', '=','Survey.surveyId')
					->select('Survey_q.*')
					->where(
						[
						['Survey_q.surveyId', '=', $surveyId],
	            		['Survey_a.empId', '=', null],
	            	])
					->get();
?>
  @if(count($questions) > 0)
  <div class="row">
	            @foreach($questions as $question)
					
						<div class="col-md-4 col-sm-8">
							<h3>
								{{$question->question}}
							</h3>
							
								{!! Form::open(['action' => 'SurveysController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']) !!}
									@if($question->typeId == '1')
									<div class="form-group">
										{{Form::textArea('answer', '', ['class' => 'form-control','rows' => 2, 'cols' => 40,'placeholder' => 'Write your answer'])}}
									</div>
									@else($question->typeId =='2')
									<div class="form-group">
										{{Form::radio('answer', '1')}} 1
										{{Form::radio('answer', '2') }} 2
										{{Form::radio('answer', '3') }} 3
										{{Form::radio('answer', '4') }} 4
										{{Form::radio('answer', '5') }} 5
									</div>
									@endif
                					<div class="form-group">
										{{Form::hidden('surveyId', $surveys->surveyId)}}
                    					{{Form::hidden('questionId', $question->questionId)}}
               	 					</div>
               	 					{{Form::submit('Submit', ['class' => 'btn btn-primary'])}}		
                				{!! Form::close() !!}
							
						</div>
					
				@endforeach
			</div>
				@else
					<h3>You have finished this survey</h3>
				@endif
@endsection