@extends('layouts.app')

@section('content')
    
    

@if(count($trainingrequests) > 0)
 @foreach($trainingrequests as $trainingrequest)
 
 

<div class="col-lg-6">
<div class="well col-lg-12">
	<div class="row">
		<div class="col-lg-12">
			<h3>
				
			</h3>
            <?php
				$trainingId = $trainingrequest->trainingId;
				$surveyName = DB::table('Survey')
					->where('trainingId', $trainingId)
					->value('surveyName');
                
				?>
                <h3><a href="/surveys/{{$trainingrequest->surveyId}}">{{$surveyName}}</a></h3>
		</div>
	</div>
	</div>
</div>
</a>
@endforeach
@else
<h4>No surveys found</h4>
@endif @endsection