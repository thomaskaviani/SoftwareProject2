@extends('layouts.app')
@section('content')
<?php
        $userId = auth()->user()->empId;
        $manager = DB::table('EmployeeDB')->where('empId', $userId)->value('manager');
        
?>
    <h1>All trainings</h1>
    @if(count($trainings) > 0)
   
        @foreach($trainings as $training)
   
            
        <div class="well col-md-4" style="min-height:200px">
                    <div class="col-md-12 col-sm-4 text-center">
                        <h3><a href="/trainings/{{$training->trainingId}}">{{$training->name}}</a></h3>
                        <div class="text-center">
                        {!!Form::open(['action' => ['TrainingRequestsController@store'], 'method' => 'POST'])!!}
                                    {{Form::hidden('trainingId', $training->trainingId)}}
                                    {{Form::hidden('name', $training->name)}}
                                    {{Form::hidden('goal', $training->goal)}}
                                    {{Form::hidden('forManager', $manager)}}
                                    {{Form::hidden('_method', 'POST')}}
                                    {{Form::submit('Request',['class' => 'btn btn-danger'])}}
                        {!!Form::close()!!}
                        </div>
                    </div>
            
            </div>
        @endforeach
       
    @else
        <p>No trainings found </p>
    @endif
@endsection