@extends('layouts.app')

@section('content')
<?php
$trainingId = $training->trainingId;
				$sessions = DB::table('Sessions')
					->select('Sessions.*')
					->where('Sessions.trainingId', '=', $trainingId)
                    ->orderBy('Sessions.startTime')
					->get();

        $userId = auth()->user()->empId;
        $manager = DB::table('EmployeeDB')->where('empId', $userId)->value('manager');
        
?>
<a href="/trainings" class="btn btn-default">Go back</a>
@if(count($sessions) > 0)
<h1 class="text-center"><u>{{$training->name}}</u></h1>
				@foreach($sessions as $session)
				<?php
				$teacherId = $session->teacherId;
				$teacher = DB::table('Teacher')
					->where('Teacher.teacherId', '=', $teacherId)
					->value('teacherName');

					$addressId = $session->addressId;
				$street = DB::table('Address')
					->where('Address.addressId', '=', $addressId)
					->value('street');
					$number = DB::table('Address')
					->where('Address.addressId', '=', $addressId)
					->value('number');
					$bus = DB::table('Address')
					->where('Address.addressId', '=', $addressId)
					->value('bus');
					$postalcode = DB::table('Address')
					->where('Address.addressId', '=', $addressId)
					->value('postalcode');
					$place = DB::table('Address')
					->where('Address.addressId', '=', $addressId)
					->value('place');
					$country = DB::table('Address')
					->where('Address.addressId', '=', $addressId)
					->value('country');
?>

						<div class="col-md-6 col-sm-6 text-center">
							<h3>
                            
								<b>{{$session->sessionName}}</b>
							</h3>
                            <h4>
								Start time: {{$session->startTime}}
							</h4>
                             <h4>
								End time: {{$session->endTime}}
							</h4>
						<h4>
							Teacher: {{$teacher}}
						</h4>
						<h4><b>Location</b></h4>
						<h4>
								{{$street}} {{$number}}, {{$place}} {{$postalcode}}
							</h4>
						</div>
					
				@endforeach
				@else
					<h3>There are no sessions</h3>
				@endif
				<div class="col-md-12 text-center">
{!!Form::open(['action' => ['TrainingRequestsController@store'], 'method' => 'POST','class'=>'text-center'])!!}
                                    {{Form::hidden('trainingId', $training->trainingId)}}
                                    {{Form::hidden('name', $training->name)}}
                                    {{Form::hidden('goal', $training->goal)}}
                                    {{Form::hidden('forManager', $manager)}}
                                    {{Form::hidden('_method', 'POST')}}
                                    {{Form::submit('Request',['class' => 'btn btn-danger text-center'])}}
                        {!!Form::close()!!}
    
				</div>

    
@endsection