@extends('layouts.app')

@section('content')
    <h1>All sessions</h1>
    @if(count($sessions) > 0)
        @foreach($sessions as $session)
            <div class="well">
                <div class="row">
                    
                    <div class="col-md-8 col-sm-8">
                        <h3><a href="/surveys/{{$session->sessionId}}">{{$session->sessionName}}</a></h3>
                        <h1>{{$session->startTime}}</h1>
                        <h1>{{$session->endTime}}</h1>
                    </div>
                </div>
            </div>
        @endforeach
        {{$sessions->links()}}
    @else
        <p>No sessions found </p>
    @endif
@endsection