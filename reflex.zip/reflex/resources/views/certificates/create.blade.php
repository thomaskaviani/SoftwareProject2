@extends('layouts.app')

@section('content')
    <h1>Upload certificate </h1>
    {!! Form::open(['action' => 'CertificatesController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']) !!}
        <div class="form-group">
            {{Form::label('description','Description')}}
            {{Form::text('description', '', ['class' => 'form-control', 'placeholder' => 'Description'])}}
        </div>
        
        <div class="form-group">
            {{Form::file('file')}}
        </div>
        {{Form::submit('Upload', ['class'=>'btn btn-primary'])}}
    {!! Form::close() !!}
    
    
@endsection