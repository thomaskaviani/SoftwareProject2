@extends('layouts.app')

@section('content')
    <h1></h1>
    @if(count($certificates) > 0)
        
            <div class="well">
                    <div class="row">
                    @foreach($certificates as $certificate)
                
                    <div class="col-md-4 col-sm-4 text-center">
                        <img style = "max-height:150px" src="/storage/files/{{$certificate->file}}">
                        <h3><a href="/certificates/{{$certificate->certificateId}}">{{$certificate->description}}</a></h3>
                    </div>
                @endforeach
            </div>
            </div>
        
    @else
        <h4>No certificates found </h4>
    @endif
<div class="text-center">
    <a href="/certificates/create" class="btn btn-primary text-center">Upload Certificate</a>
</div>
@endsection