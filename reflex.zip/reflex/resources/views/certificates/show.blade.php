@extends('layouts.app')

@section('content')
<a href="/certificates" class="btn btn-default">Go back</a>
    <h1>{{$certificate->title}}</h1>
     <img style = "width:100%" src="/storage/files/{{$certificate->file}}">
     <br><br>
    <div>
        {!!$certificate->description!!}
    </div>
    <hr>

    <hr>
    @if(Auth::user()->empId == $certificate->empId)

                {!!Form::open(['action' => ['CertificatesController@destroy', $certificate->certificateId], 'method' => 'certificate','class'=>'pull-right'])!!}
                    {{Form::hidden('_method', 'DELETE')}}
                    {{Form::submit('Delete',['class' => 'btn btn-danger'])}}
                {!!Form::close()!!}
        @endif
        
@endsection